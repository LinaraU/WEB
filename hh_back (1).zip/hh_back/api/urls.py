
from django.urls import path
from api.views import company_list, vacancies_list, vacancy_detail, company_detail, vacancies_by_company, top_ten

urlpatterns = [
  path('companies/', company_list),
  path('companies/<int:company_id>/', company_detail),
  path('vacancies/', vacancies_list),
  path('vacancies/<int:vacancy_id>/', vacancy_detail),
  path('companies/<int:companies_id>/vacancies', vacancies_by_company),
  path('vacancies/top_ten/', top_ten)
]
